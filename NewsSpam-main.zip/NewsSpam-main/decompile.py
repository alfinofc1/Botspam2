import base64
exec(base64.b64decode('cHJpbnQoImJyZWUgSmFuIERlYyBEZWMgbGFoIHN1dXV1dXV1dXV1dWUiKQ=='))
