# NewsSpam
Script Spam Whatsapp Sms Terbaru 2024 😘

<p align="center">

  <a href="https://github.com/Dra-Ganzz"><img src="http://readme-typing-svg.herokuapp.com?color=BF00FF&center=true&vCenter=true&multiline=false&lines=Kasih+Star+Dong+^_^" alt="UwU">

 <p align="center">

   <a href="https://github.com/Dra-Ganzz"><img src="http://readme-typing-svg.herokuapp.com?color=FFD700&center=true&vCenter=true&multiline=false&lines=Duar+Follow+github+Vindra+Ganzz+Dong+^_^" alt="UwU">

 `• Yang decrypt Fuck you men , cape anjing buatnya/dog cape for terimakasih ☺️`
 
 | Kelebihan | Check |
|--------|--------|
| **Menu Tmbhan** |[✔️](https://github.com/Dra-Ganzz) |
| **Spam Massive Kebanyak nomor** |[✔️](https://github.com/Dra-Ganzz) |
| **Views Titok** |[✔️](https://github.com/Dra-Ganzz) |
| **Sekian terimakasih** |[✔️](https://github.com/Dra-Ganzz) |
---------

# `Install Termux`

```python
pkg update && pkg upgrade
pkg install python
pkg install python-pip
pkg install git
git clone https://github.com/Dra-Ganzz/NewsSpam
cd NewsSpam
pip install -r requirements.txt
git pull
python run.py
```

`jalan Script`
```python
cd Spm-Whatsapp
ls
git pull
python run.py
```

# `Install Linux`
```python
sudo apt update
sudo apt upgrade
sudo apt install git jq nodejs
sudo apt install python3-pip
pip install rich
pip install rich-cli
git clone https://github.com/Dra-Ganzz/NewsSpam
cd NewsSpam
pip install -r requirements.txt
python run.py
```

`Tutorial Videos Klik Logo Yt`

[![](https://img.shields.io/badge/Tutorial-white?logo=YouTube&logoColor=Brighred&labelColor=red)](https://youtu.be/qfiNH18VkC8?si=PTTaI20fW-g0Te4B) `<-- klik caranya`

</p>

<p align="center">
  <img src="Data/Screenshot_20241111-080958.png">
</p>

Menu 2 Premium

</p>
Update premium 

<p align="center">
  <img src="Data/Screenshot_20241118-064503.png">
</p>

• Yang mau beli bisa chat Tele > `t.me/vindraganzz`
